Just paste this into your \AppData\ folder to enable the night theme on the "one tab" extention.


Hit "Windows Key + R" type "%appdata" (without the quotation marks) click back from %\AppData\Roaming to %\AppData (just click "AppData" in the navigation bar.) then just drag and drop the "Local" folder from the zip into empty space in the AppData folder. Now just click "Replace the file in this destination" and your installation is complete.